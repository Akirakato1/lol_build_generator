# __init__.py

# Version of the lol_build_generator package
__version__ = "1.0.2"
